export enum TRANSACTIONENUM {
    DEPOSIT = 'Deposit',
    SWAP = 'Swap',
    WITHDRAW = 'Withdraw',
    WITHDRAW_FIAT = 'Withdraw Fiat',
}

export enum TRANSACTIONSTATUSENUM {
    COMPLETED = 'Completed',
    PENDING = 'Pending',
    REJECTED = 'Rejected',
}